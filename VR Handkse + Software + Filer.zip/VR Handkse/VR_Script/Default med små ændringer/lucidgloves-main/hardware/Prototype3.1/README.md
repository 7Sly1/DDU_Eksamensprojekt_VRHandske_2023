# LucidGloves Hardware Prototype 3.1

See [readme.md](readme.md) for the master readme of this repository.

This folder contains the STl files for Prototype 3.1 of the LucidGloves.
Please see [Printing guide](https://github.com/LucidVR/lucidgloves-hardware/wiki/Parts-Printing-Guide) for printing instructions.

Here is a list of modified versions of Prototype 3.1:  
* Feel free to pull request a repo link to your modded version.
  - Should follow the structure of "Mod name - mod creator - link to mod"
